document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const bookingModal = document.getElementById('bookingModal');
    const closeModal = document.querySelector('.close-modal');
    const bookingForm = document.getElementById('bookingForm');
    const coursesContainer = document.querySelector('.courses-container');
    
    const courses = [
        {
            id: 1,
            name: "تطوير الويب المتكامل",
            description: "تعلم تطوير مواقع الويب باستخدام HTML, CSS, JavaScript وتقنيات الويب الحديثة.",
            duration: "8 أسابيع",
            price: "120شيكل",
            image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&auto=format&fit=crop&w=1172&q=80"
        },
        {
            id: 2,
            name: "برمجة بايثون",
            description: "احترف لغة بايثون من الأساسيات إلى المستوى المتقدم وتطبيقاتها في تحليل البيانات.",
            duration: "6 أسابيع",
            price: "1000 شيكل",
            image: "https://images.unsplash.com/photo-1526379879527-8559ecfcaec5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
        },
        {
            id: 3,
            name: "تطوير تطبيقات الجوال",
            description: "تعلم بناء تطبيقات الجوال لنظامي iOS و Android باستخدام React Native.",
            duration: "10 أسابيع",
            price: "300 شيكل",
            image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
        },
        {
            id: 4,
            name: "أمن المعلومات",
            description: "تعلم أساسيات أمن المعلومات وكيفية حماية الأنظمة والشبكات من الهجمات الإلكترونية.",
            duration: "7 أسابيع",
            price: "250 شيكل",
            image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
        }
    ];
    
    function loadCourses() {
        if (!coursesContainer) return;
        
        coursesContainer.innerHTML = '';
        
        courses.forEach(course => {
            const courseCard = document.createElement('div');
            courseCard.className = 'course-card';
            courseCard.innerHTML = `
                <img src="${course.image}" alt="${course.name}" class="course-img">
                <div class="course-info">
                    <h3>${course.name}</h3>
                    <p class="course-desc">${course.description}</p>
                    <div class="course-meta">
                        <span class="course-duration"><i class="far fa-clock"></i> ${course.duration}</span>
                        <span class="course-price">${course.price}</span>
                    </div>
                    <button class="book-btn" data-course="${course.name}">احجز الآن</button>
                </div>
            `;
            
            coursesContainer.appendChild(courseCard);
        });
        
        document.querySelectorAll('.book-btn').forEach(button => {
            button.addEventListener('click', function() {
                openBookingModal(this.getAttribute('data-course'));
            });
        });
    }
    
    function openBookingModal(courseName = '') {
        if (bookingModal) {
            bookingModal.style.display = 'flex';
            if (courseName && document.getElementById('course')) {
                document.getElementById('course').value = courseName;
            }
        }
    }
    
    function closeBookingModal() {
        if (bookingModal) bookingModal.style.display = 'none';
    }
    
    function saveBooking(bookingData) {
        let bookings = JSON.parse(localStorage.getItem('shefratcodeBookings')) || [];
        bookingData.id = Date.now();
        bookingData.date = new Date().toLocaleString();
        bookings.push(bookingData);
        localStorage.setItem('shefratcodeBookings', JSON.stringify(bookings));
    }
    
    function handleBookingFormSubmit(e) {
        e.preventDefault();
        
        const bookingData = {
            name: document.getElementById('name').value,
            phone: document.getElementById('phone').value,
            email: document.getElementById('email').value,
            course: document.getElementById('course').value
        };
        
        saveBooking(bookingData);
        alert('تم إرسال حجزك بنجاح! سنتصل بك قريباً.');
        closeBookingModal();
        bookingForm.reset();
    }
    
    function handleContactForm() {
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const contactData = {
                    name: this.querySelector('input[name="name"]').value,
                    email: this.querySelector('input[name="email"]').value,
                    message: this.querySelector('textarea[name="message"]').value,
                    date: new Date().toLocaleString()
                };
                
                let contacts = JSON.parse(localStorage.getItem('shefratcodeContacts')) || [];
                contacts.push(contactData);
                localStorage.setItem('shefratcodeContacts', JSON.stringify(contacts));
                
                alert('شكراً لك! تم إرسال رسالتك بنجاح وسنرد عليك قريباً.');
                this.reset();
            });
        }
    }
    
  function setupPortfolio() {
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    portfolioItems.forEach(item => {
        item.addEventListener('click', function() {
            const imgSrc = this.querySelector('img').src;
            const imgAlt = this.querySelector('img').alt;
            
            const imageModal = document.createElement('div');
            imageModal.className = 'modal';
            imageModal.innerHTML = `
                <div class="modal-content" style="max-width: 90%; max-height: 90%;">
                    <span class="close-modal">&times;</span>
                    <img src="${imgSrc}" alt="${imgAlt}" style="width: 100%; height: auto; border-radius: 5px;">
                </div>
            `;
            
            document.body.appendChild(imageModal);
            imageModal.style.display = 'flex';
            
            imageModal.querySelector('.close-modal').addEventListener('click', function() {
                document.body.removeChild(imageModal);
            });
            
            imageModal.addEventListener('click', function(e) {
                if (e.target === imageModal) {
                    document.body.removeChild(imageModal);
                }
            });
        });
    });
}
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }
    
    if (closeModal) closeModal.addEventListener('click', closeBookingModal);
    
    if (bookingModal) {
        bookingModal.addEventListener('click', (e) => {
            if (e.target === bookingModal) closeBookingModal();
        });
    }
    
    if (bookingForm) bookingForm.addEventListener('submit', handleBookingFormSubmit);
    
    document.querySelectorAll('.cta-btn, .view-all-btn').forEach(button => {
        if (!button.href || button.href.includes('#')) {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                openBookingModal();
            });
        }
    });
    
    loadCourses();
    handleContactForm();
    
    if (window.location.pathname.includes('portfolio.html') || window.location.pathname.includes('portfolio')) {
        setupPortfolio();
    }
    
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            if (navLinks.classList.contains('active')) {
                hamburger.classList.remove('active');
                navLinks.classList.remove('active');
            }
        });
    });
});